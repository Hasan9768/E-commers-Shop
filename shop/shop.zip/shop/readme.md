==============Database Project Setup==============
=> Step 1
   Start your server software (XAMPP or WAMP) 
=> Step 2 
   Copy and Paste this folder "project" to "htdoc" folder (XAMPP)
   Copy and Paste this folder "project" to "WWW" folder (WAMP)
=> Step 3
    Go to your browser and browse http://127.0.0.1/[folder name]/setup/setup.php
    Go to your browser and browse http://127.0.0.1/project/setup/setup.php

==================Your are done===================

	