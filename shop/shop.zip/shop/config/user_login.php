<script>
			function myFunction(paths) {
			  setTimeout(function(){				 
				  window.location.href = paths;
				  
				  }, 1000);
			}
			</script>
<?php
	include "db.php";
	$msg="";
	if(isset($_GET['return']))
	{
		$return= $_GET['return'];
	}else{
		$return="";
	}
		
	
		if(isset($_COOKIE['user']))
		{
		echo	$redirects = "
			<script>
			var a = '../public/';
				myFunction(a);
			</script>";
			$msg .="<div class='bg-success text-light p-2'>You already Login In</div>";
			
		}
		
			
		
		
	
	
	
	if(isset($_POST['submit']))
	{
		$user = $_POST['user'];
		$pass = $_POST['pass'];
		$passe = md5($pass);
		$type = 1;
		if($type == 1){ // 1 means admin
			
			$q= "select * from user where phone like '%".$user."%' and pass like '%".$pass."%'";
			
			$array = mysqli_fetch_assoc(mysqli_query($connect,$q));
			$id = $array['id'];
			$duser = $array['phone'];
			$dpass = $array['pass'];
			$username = $array['name'];
			
			if($duser == $user && $dpass == $pass)
			{
				$n = 1;
			}else{ $n = 0;
			}
			$info= "public";
			$redirects = "
			<script>
			var a = '../public/';
				myFunction(a);
			</script>";
		}
		
		
		
		
		
		if($n>0)
		{
			setcookie('user',$username,time() + (86400), "/");
			setcookie("id",$id,time() + (86400), "/");
			echo $redirects;	
			$msg.="<div class='bg-success text-light p-2'>Login Successful. Just 1s Redirect to home page <a href='login.php'>Login</a></div><br />";			
		}
		else{
			$msg.="<div class='bg-danger text-light p-2'>Sorry, Login Failed.</div><br />";
		}
		$s= $connect->query($q);
		
		if($connect->error)
		{
			 $msg.="<div class='bg-danger text-light p-2'>$connect->error</div> <br />";
		}
		else{
			 
		}
		
		
	}

		
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="../bootstrap-4.3.1-dist/css/bootstrap.min.css" />
	<link rel="stylesheet" href="../bootstrap-4.3.1-dist/js/bootstrap.js" />
	<title>Login -<?php echo $app_name;?></title>
</head>
<body>
	<div class="bg-info h2 text-light p-2"><div class="container">
	<?php echo $app_name;?>
	<span class="float-right"><a class="text-light h6" href="login.php">Admin</a> &nbsp;<a class="text-light h6" href="../public/">Public View</a></span>
	</div></div>
	<div class="container">	
	<br />
		<div class="w-50 p-5 shadow p-3 mb-5 bg-white rounded">
			<div class="h4">Login Panel <small>(User)</small></div>
			<hr />
			<form  action="user_login.php" method="POST">
					<br /><?php echo $msg;?>				
					<label for="user">Phone number</label>
					<input class="form-control" type="text" name="user"/>
					<br />
					<label for="user">Password</label>
					<input class="form-control" type="password" name="pass"/>
							
					<br />
					<p class="text-info">Not registerd? <a href="user_reg.php">Go here</a></p>		
					<br />
				<input class="form-control btn-success" type="submit" value="Login" name="submit"/>
			
			</form>
		</div>
	</div>

	
</body>
</html>