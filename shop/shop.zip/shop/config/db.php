<?php

		$connect = mysqli_connect('localhost','root','','database');
		if(!$connect){echo"Database Connection Problem"; header("location: ../setup/setup.php");}
		$app_name = "Ecommerce business";
		function refresh()
		{
			return "<script>
			 myFunction(paths) {
			  setTimeout(function(){				 
				  window.location.href = paths;
				  
				  }, 1000);
			}
			</script>";
		}
	
?>