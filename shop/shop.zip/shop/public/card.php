<?php
	include "../config/db.php";
	$msg= "";
		$product_id = $_GET['product_id'];
	if(!isset($_COOKIE['user'])){header("location:../config/user_login.php?return=$product_id");} 
		if(!isset($_GET['product_id']))
	{
		header("location: index.php");
	}
	$product_id = $_GET['product_id'];
	
	$product_id = $_GET['product_id'];
	$show = mysqli_fetch_assoc(mysqli_query($connect,"Select * from product where product_id=$product_id"));
	$product_count  = $show['quantity'];
	$categroy_code = $show['category'];
	$categroy_name = mysqli_fetch_assoc(mysqli_query($connect,"select * from category where category_id=$categroy_code"));
	$userid= $_COOKIE['id'];
	$user_info = mysqli_fetch_assoc(mysqli_query($connect,"select * from user where id=$userid"));
	
	
	
	
	
	if(isset($_POST['submit']))
        {
            $ids = $_POST['tnxid'];
            $type = $_POST['type'];
			
            if($ids == 112233 OR $type == 0)
            {
				$newq = $product_count - 1;
                $query = "UPDATE `product` SET `quantity` = '$newq' WHERE `product`.`product_id` = $product_id";
               $ok= $connect->query($query);
			  
                if($connect->error){
                     $msg .= "<div class='bg-danger p-2 text-light'>Something is worng</div>";
                }
               else
               {
                $msg .="<div class='bg-success p-2 text-light'>Thank you! Process Complete We will contact soon</div>";
               }
            }
			else
				$msg .= "<div class='bg-danger p-2 text-light'>Wrong Transaction ID</div>";
        }
	
	
	
	
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>

		<meta charset="UTF-8">
	<link rel="stylesheet" href="../bootstrap-4.3.1-dist/css/bootstrap.min.css" />
	<link rel="stylesheet" href="../fa/css/all.css" />
	<title>Welcome to <?php echo $app_name;?></title>
</head>
<body>
	<div class="bg-info p-2">
		<div class="container">		
				<span class="h4 text-light">
				<a class="text-decoration-none text-light" href="index.php"><?php echo $app_name;?></a>
				</span> 
		
			<span class="float-right text-light">
			Welcome (<?php echo $_COOKIE['user'];?>) &nbsp;
			<?php if(isset($_COOKIE['user'])){ ?>
			<a class="h5 text-light text-decoration-none" href="../config/logout.php" title="Logout"> <i class="fas fa-sign-out-alt"></i></a>
			
			<?php }else{ ?>
			<a class="h5 text-light text-decoration-none" href="../config/login.php" title="Login"> <i class="fas fa-sign-in-alt"></i></a>
			<?php } ?>
			</span>
		</div>
	</div>
	<div class="container">
	<br /><br />
		<form action="card.php?product_id=<?php echo $product_id;?>" method="POST">
		
		<div class="border p-2 bg-light">
		
		<?php echo $msg;?>
			
			<div class="h5">Name: <?php echo $show['name'];?> <span class="badge badge-info float-right"><?php echo $show['quantity'];?>&#2547; </span></div>
				<div class="h6">Category: <?php echo $categroy_name['name'];?></div>
				<div class="h6">Full Details: <br /></div>
				<p><?php echo $show['details'];?></p>
		
		</div>	<br />
		<div class="border p-2 bg-light">
		<div class="h5">User Information</div>		<hr />
				<div class="h6">Name: <?php echo $user_info['name'];?> </div>
				<div class="h6">Contact: <?php echo $user_info['phone'];?></div>
				<div class="h6">Email: <?php echo $user_info['email'];?></div>
				<div class="h6">Delivery Address: <?php echo $user_info['address'];?></div>
				
				
		
		</div>
		<div class="h5">Payment method</div>
		
			<div class="radio">
                            <label><input type="radio" name="type" value="1" checked>bKash</label>
                            &nbsp; &nbsp; 
                            <label><input type="radio" name="type" value="2">DBBL</label>
                            &nbsp; &nbsp; 
                            <label><input type="radio" name="type" value="3">Sure Case</label>
							&nbsp; &nbsp; 
                            <label><input type="radio" name="type" value="0">Cash on delivary</label>
                            </div>	
                <label class="h6" for="tnxid">Enter Transaction ID</label>
                <input class="form-control p-2 m-1" type="text" name="tnxid" id="tnxid">
                <input type="submit" value="Confirm" name="submit" class="btn-success text-light btn">
		</form>
	</div>
</body>
</html>