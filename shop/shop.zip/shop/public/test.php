	<?php echo $msg;?>
				<form class="form-group" action="search.php" method="POST">		
				<label class="h5" for="name">Search Driving license:</label>
				<input class="form-control" type="text" name="search"/>
				<br />		
			<input class="form-control btn-info" type="submit" value="Search" name="submit" />								
		</form>

		<?php echo $table;?>