<?php
	include"../config/db.php";$msg = "";$tr = "";$table = "";
	if(!isset($_COOKIE['user'])){$user="Guest";} else{$user=$_COOKIE['user'];}
	$men_code= 1;
	$women_code = 2;
	$get_product_3 = mysqli_query($connect,"select * from product where category=$men_code");
	$get_product_5 = mysqli_query($connect,"select * from product where category=$women_code");
	if(isset($_POST['submit']))
	{
		$search_data = $_POST['search'];
		$q = "select * from driver_information where license_number LIKE '%".$search_data."%' ";
		$data = mysqli_query($connect,$q);
		$count = mysqli_num_rows($data);
		if($count>0)
		{
			while($array= mysqli_fetch_assoc($data))
			{
				$tr .="<tr>
				<td>".$array['name']."</td>
				<td>".$array['phone_number']."</td>
				<td>".$array['license_number']."</td>
				<td>".$array['address']."</td>
				<td>".$array['case_count']."</td>
				<td>".$array['rating']."</td>
				<td>".$array['time']."</td>				
				<td><a href='add.php?driver_id=".$array['driver_id']."'>Case</a></td>				
				</tr>";
				
			}
			$table = "<table class='table'>
			<tr>
				<th>Name</th>
				<th>Phone</th>
				<th>License</th>
				<th>Address</th>
				<th>Case Count</th>
				<th>Rating</th>
				<th>Joined at</th>
				<th>Action</th>
			</tr>
			$tr
			</table>";

		}else
		{
			$table= "No data found <i class='far fa-frown'></i>";
		}
	}
	
?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="../bootstrap-4.3.1-dist/css/bootstrap.min.css" />
	<link rel="stylesheet" href="../fa/css/all.css" />
	
	<title>Welcome -<?php echo $app_name;?></title>
</head>
<body>
	<div class="bg-info p-2">
		<div class="container">		
				<span class="h4 text-light">
				<a class="text-decoration-none text-light" href=""><?php echo $app_name;?></a>
				</span> 
		
			<span class="float-right text-light">
			Welcome (<?php echo $user;?>) &nbsp;
			<?php if(isset($_COOKIE['user'])){ ?>
			<a class="h5 text-light text-decoration-none" href="../config/logout.php" title="Logout"> <i class="fas fa-sign-out-alt"></i></a>
			
			<?php }else{ ?>
			<a class="h5 text-light text-decoration-none" href="../config/user_reg.php" title="Registration"> Sing Up</a>
			<a class="h5 text-light text-decoration-none" href="../config/user_login.php" title="Login"> <i class="fas fa-sign-in-alt"></i></a>
			
			<?php } ?>
			</span>
		</div>
	</div>
	<div class="container">
		
		<div class="row p-1">
			<div class="h6 p-3 w-100 bg-light">Caterogy Men</div><hr />
			
			<?php  while($five = mysqli_fetch_assoc($get_product_5)) {?>
				<div class="p-1">
					<div class="card" style="width: 17rem;">
					  <img src="../img/product.jpg" class="card-img-top" alt="...">
					  
					  <div class="card-body">
						<h5 class="card-title"><?php echo $five['name'];?>
						
							
								<span class="float-right badge badge-secondary">
								<?php echo $five['prize'];?> &#2547; 
							</span>	</h5>					
						<a href="view_product.php?product_id=<?php echo $five['product_id'];?>" class="btn btn-primary">Buy Now</a>
					  </div>
				  
					</div>
				</div>
				<?php }?>

		</div>

<!-------Women Category------------>
		<div class="row p-1">
			<div class="h6 p-3 w-100 bg-light">Caterogy Women</div><hr />
			
			<?php  while($five = mysqli_fetch_assoc($get_product_3)) {?>
				<div class="p-1">
					<div class="card" style="width: 17rem;">
					  <img src="../img/product.jpg" class="card-img-top" alt="...">
					  <div class="card-body">
						<h5 class="card-title"><?php echo $five['name'];?> 
							<span class="float-right badge badge-secondary">
								<?php echo $five['prize'];?> &#2547; 
							</span>
						</h5>						
						<a href="view_product.php?product_id=<?php echo $five['product_id'];?>" class="btn btn-primary">Buy Now</a>
					  </div>
				  
					</div>
				</div>
				<?php }?>

		</div>
		
		
	</div>

		
		
</body>
</html>