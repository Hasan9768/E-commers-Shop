<?php
	//site traffic

	if(isset($_COOKIE['admin']))
	{
		header("location: admin/index.php");
		echo "bbbbb";
	}
	else if(isset($_COOKIE['user']))
	{
		header("location: public/");
		echo "cccccc";
	}
	else
	{
		header("location: public/");
	}
	
	var_dump($_COOKIE);

?>