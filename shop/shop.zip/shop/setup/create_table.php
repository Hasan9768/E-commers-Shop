<?php
	include "../config/db.php";
	$msg="";	$msgs="";
	
	
	$table_admin= "CREATE TABLE admin(
		id int AUTO_INCREMENT NOT null PRIMARY KEY,
		user varchar(30),
		pass varchar(30),				
		time timestamp
	)";
	
	$table_user= "CREATE TABLE user(
		id int AUTO_INCREMENT NOT null PRIMARY KEY,
		name varchar(50),
		email varchar(50),
		phone varchar(30),				
		address varchar(30),				
		pass varchar(30),				
		time timestamp
	)";
	
	$table_category= "CREATE TABLE category(
									category_id int AUTO_INCREMENT NOT null PRIMARY KEY,
									name int
									
								)";
								
	
	$table_product = "CREATE TABLE product(
		product_id int AUTO_INCREMENT NOT null PRIMARY KEY,
		name varchar(230),	
		brand varchar(230),	
		quantity varchar(15),
		details varchar(20),	
		prize int,
		category int,
		FOREIGN KEY(category) REFERENCES category(category_id),		
		time timestamp
	)
	";

								
	$table_buy= "CREATE TABLE buy_product(
									buy_id int AUTO_INCREMENT NOT null PRIMARY KEY,
									product_id int,									
									FOREIGN KEY(product_id) REFERENCES product(product_id)	
								)";
	$create_1 = $connect->query($table_admin);
	$create_2 = $connect->query($table_user);
	$create_3 = $connect->query($table_category);
	$create_4 = $connect->query($table_product);
	$create_5 = $connect->query($table_buy);
	
	if(!$create_1){$msg.= $connect->error."<br />";}
	if(!$create_2){$msg.= $connect->error."<br />";}
	if(!$create_3){$msg.= $connect->error."<br />";}
	if(!$create_4){$msg.= $connect->error."<br />";}
	if(!$create_5){$msg.= $connect->error."<br />";}
	else
	{
		$msgs .= "<center><div class='mx bg-danger text-light'>
		<div class='h2 bg-danger text-light'>	<?php echo $msg;?> Table Created successfully Now,</div>
	<a href='../admin/register_admin.php'> Register </a>New User..
	</div><center>"; 
	}
	
	 
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>

	<meta charset="UTF-8">
	
	<link rel="stylesheet" href="../bootstrap-4.3.1-dist/css/bootstrap.min.css" />
	<link rel="stylesheet" href="../bootstrap-4.3.1-dist/js/bootstrap.js" />
	
	<title>Table Create</title>
</head>
<body>
	
	<?php echo $msg;?>
	<?php echo $msgs;?>
	
	
	
</body>
</html>